

public class FieldLengthException extends Exception{

    public FieldLengthException() {

    }
    public FieldLengthException(String message) {

        super(message);


    }

}