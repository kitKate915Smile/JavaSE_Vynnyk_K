

public class IncorrectSalaryException extends Exception {

    IncorrectSalaryException()
    {}

    IncorrectSalaryException(String message)
    {
        super(message);
    }



}