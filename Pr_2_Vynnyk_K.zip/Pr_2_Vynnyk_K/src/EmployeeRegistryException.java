public class EmployeeRegistryException extends Exception{

    public EmployeeRegistryException() {}

    public EmployeeRegistryException(String msg)
    {
        super(msg);
    }


}