public class Main {

    public static void main(String[] args) {

        Registry hr = Registry.getInstance();

        Employee emp_1 = null;

        try {
            emp_1 = new Employee("Pieter ","Berk",12000);
            emp_1.printEmployee();
            hr.addEmployee(emp_1);
        } catch (EmployeeRegistryException e) {
            e.printStackTrace();
        }
        try {
            emp_1 = new Employee("Nill","Kefri",10000);
            emp_1.printEmployee();
            hr.addEmployee(emp_1);
        } catch (EmployeeRegistryException e) {
            e.printStackTrace();
        }
        try {
            emp_1 = new Employee("Diyana","Berigan",10550);
            emp_1.printEmployee();
            hr.addEmployee(emp_1);
        } catch (EmployeeRegistryException e) {
            e.printStackTrace();
        }

    }
}