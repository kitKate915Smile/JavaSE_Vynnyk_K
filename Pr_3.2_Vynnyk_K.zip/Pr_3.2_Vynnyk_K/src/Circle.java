public class Circle extends Shape{

    public Circle(){

        type = "Circle";

    }
}