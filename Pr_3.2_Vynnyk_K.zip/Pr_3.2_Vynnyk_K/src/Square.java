public class Square extends Shape{

    public Square(){

        type = "Square";

    }
}
