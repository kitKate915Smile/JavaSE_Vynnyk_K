public class EmployeeInRegistryException extends Exception{

    public EmployeeInRegistryException() {}

    public EmployeeInRegistryException(String msg) {super(msg);}
}
