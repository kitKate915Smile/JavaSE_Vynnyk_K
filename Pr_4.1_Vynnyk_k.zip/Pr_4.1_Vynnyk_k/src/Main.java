public class Main {
    public static void main(String[] args){

        Registry hr = Registry.getRegistry();

        Manager ceo = null;
        try{
            ceo = new Manager("Vynnyk", "Kateryna", 6000, 200, 0);
            ceo.printemployee();
            hr.addEmployee(ceo);
        } catch (FieldLengthLimitException e){
            System.out.println(e.getMessage());
        } catch (IncorrectSalaryException e) {
            System.out.println(e.getMessage());
        } catch (EmployeeInRegistryException e){
            System.out.println(e.getMessage());
        }

        employee salesHead = null;
        try{
            salesHead = new employee("Wozzie", "Unknow", 24000, ceo.id);
            salesHead.printemployee();
            hr.addEmployee(salesHead);
        } catch (FieldLengthLimitException e){
            System.out.println(e.getMessage());
        } catch (IncorrectSalaryException e) {
            System.out.println(e.getMessage());
        } catch (EmployeeInRegistryException e){
            System.out.println(e.getMessage());
        }

        employee marketingHead = null;
        try{
            marketingHead = new employee("Nill", "Kefri", 15000, ceo.id);
            marketingHead.printemployee();
            hr.addEmployee(marketingHead);
        } catch (FieldLengthLimitException e){
            System.out.println(e.getMessage());
        } catch (IncorrectSalaryException e) {
            System.out.println(e.getMessage());
        } catch (EmployeeInRegistryException e){
            System.out.println(e.getMessage());
        }

        employee emp1 = null;
        try{
            emp1 = new employee("Alise", "Berk", 7500, salesHead.id);
            emp1.printemployee();
            hr.addEmployee(emp1);
        } catch (FieldLengthLimitException e){
            System.out.println(e.getMessage());
        } catch (IncorrectSalaryException e) {
            System.out.println(e.getMessage());
        } catch (EmployeeInRegistryException e){
            System.out.println(e.getMessage());
        }

        ceo.add(salesHead);
        ceo.add(marketingHead);

        salesHead.add(emp1);

        System.out.println("\nEmployee List:");
        ceo.printemployee();
        for (employee headEmployee : ceo.getBoss()) {
            System.out.print("  ");
            headEmployee.printemployee();

            for (employee emp : headEmployee.getBoss()){
                System.out.print("       ");
                emp.printemployee();
            }
        }

    }
}