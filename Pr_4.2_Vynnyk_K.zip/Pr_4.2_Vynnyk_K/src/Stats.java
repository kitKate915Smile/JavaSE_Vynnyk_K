public class Stats {
    protected int stren;
    protected int dexte;

    protected int constitutoin;
    protected int intel;
    protected int wisdo;
    protected int chari;

    public Stats(int str, int dex, int con, int in, int ws, int ch){
        constitutoin = con;
        intel = in;
        wisdo = ws;
        chari = ch;
        stren = str;
        dexte = dex;

    }

    public static Stats generate(){
        Dice dice = new Dice();

        return new Stats(dice.roll(), dice.roll(), dice.roll(), dice.roll(),
                dice.roll(), dice.roll());
    }

    public void print(){
        System.out.println("Stren: " + stren);

        System.out.println("Dexte: " + dexte);

        System.out.println("Const: " + constitutoin);

        System.out.println("Intel: " + intel);

        System.out.println("Wisdo: " + wisdo);

        System.out.println("Chari: " + chari);
    }
}