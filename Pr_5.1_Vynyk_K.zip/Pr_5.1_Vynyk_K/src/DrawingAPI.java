public interface DrawingAPI {

    public void drawCircle(int radius, int x, int y);
    public void drawSquare(int x, int y, int side);
}
