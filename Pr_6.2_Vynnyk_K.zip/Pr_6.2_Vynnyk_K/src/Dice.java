public class Dice {
    protected int roll(){
        int cub = (int) (Math.random() * 9);

        return cub;
    }
}
