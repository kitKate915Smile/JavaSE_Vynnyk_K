package Race;

public interface RaceAbstractFactory {

    public CharacterRace create();
}
