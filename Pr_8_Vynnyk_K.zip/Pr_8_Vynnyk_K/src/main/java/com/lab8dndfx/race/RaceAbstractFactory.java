package com.lab8dndfx.race;

public interface RaceAbstractFactory {
    public CharacterRace create();
}
